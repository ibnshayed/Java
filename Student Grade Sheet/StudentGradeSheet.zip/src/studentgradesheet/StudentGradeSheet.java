package studentgradesheet;

import java.io.*;
import java.util.ArrayList;

public class StudentGradeSheet {

    public StudentGradeSheet(){
        readDataFromFile("data.csv");
    }
    
    public void readDataFromFile(String filename){
        try( RandomAccessFile input = new RandomAccessFile(filename,"r")){
            //System.out.println("file is found");
            
            ArrayList < Double > attendancesMarks = new ArrayList <> ();
            ArrayList < Double > assessmentMraks = new ArrayList <> ();
            ArrayList < Double > midTermMarks = new ArrayList <> ();
            ArrayList < Double > finalTermMraks = new ArrayList <> ();
            ArrayList < Double > totalMraks = new ArrayList <> ();
            
            int NumberOfAPlus  = 0;
            int NumberOfA      = 0;
            int NumberOfAMinus = 0;

            int NumberOfBPlus  = 0;
            int NumberOfB      = 0;
            int NumberOfBMinus = 0;

            int NumberOfCPlus  = 0;
            int NumberOfC      = 0;

            int NumberOfD      = 0;
            int NumberOfF      = 0;
            
            String line;
            
            line  = input.readLine();
            line  = input.readLine();
            
            String row[] = line.split("\\,");
            
            int[] QuizFullMarks = new int[6];
            
            // Getting total mark for each quiz from row 2
            for (int i = 3, idx = 0; i < 8; i++, idx++){
                QuizFullMarks[idx] = Integer.parseInt(row[i]);
            }

            //Result Sheet Header
            
            System.out.println("ResultSheet :");
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println(" |    ID    |   NAME   |  Absents | AttendanceMraks |    Q1    |    Q2    |    Q3    |    Q4    |    Q5    |Assessment |    MID   |   FINAL  | Total Marks | Letter Grade|");
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            
            while(true){
                line = input.readLine();
                if(line == null) break;
                
                String token[] = line.split("\\,");
                
                int id = Integer.parseInt(token[0]);
                
                
                //getting Attendance Marks
                int days = Integer.parseInt(token[2]);
                double attendanceMarks = getAttendenceMarks(days);
                attendancesMarks.add(attendanceMarks);
                                
                //Getting Quiz Marks
                int[] QuizMarks = new int[6];

                for (int idx = 0, i = 3; i < 8; i++, idx++) {
                    if (token[i].length() == 0)
                        token[i] = "0";
                    QuizMarks[idx] = Integer.parseInt(token[i]);
                }
                double assessment = getAssessmentMark(QuizMarks, QuizFullMarks);
                assessmentMraks.add(assessment);
                
                //getting MidTerm Marks
                int midMarks = Integer.parseInt(token[8]);
                midTermMarks.add((double) midMarks);
                
                //getting Finals Marks
                int finals = Integer.parseInt(token[9]);
                finalTermMraks.add((double) finals);
                
                //getting Total Marks
                double total = attendanceMarks + assessment + midMarks + finals;
                totalMraks.add(total);
                
                //getting Letter Grade
                String grade = getLetterGrade(total);
                
                //print the ResultSheet
                for(int i = 0; i<=9; i++){
                    if(i == 0 ) System.out.printf(" | %-8d",id);
                    else if(i == 2 ) System.out.printf(" | %-8s | %-15.3f",token[i],attendanceMarks);
                    else if(i == 7) System.out.printf(" | %-8s | %-9.3f",token[i],assessment);
                    else if(i == 9) System.out.printf(" | %-8s | %-11.3f | %8s",token[i],total,grade);
                    else System.out.printf(" | %-8s",token[i]);
                    
                }System.out.println();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                
                // Updating the frequency of different letter grades
                if (grade == "A+")
                    NumberOfAPlus++;
                else if (grade == "A")
                    NumberOfA++;
                else if (grade == "A-")
                    NumberOfAMinus++;
                else if (grade == "B+")
                    NumberOfBPlus++;
                else if (grade == "B")
                    NumberOfB++;
                else if (grade == "B-")
                    NumberOfBMinus++;
                else if (grade == "C+")
                    NumberOfCPlus++;
                else if (grade == "C")
                    NumberOfC++;
                else if (grade == "D")
                    NumberOfD++;
                else
                    NumberOfF++;
                // Frequency update ends
            }
            
        // Calculating Min of each category
        double MinAttendanceMarks = getMin(attendancesMarks);
        double MinAssessmentMarks = getMin(assessmentMraks);
        double MinMidMarks        = getMin(midTermMarks);
        double MinFinalMarks      = getMin(finalTermMraks);
        double MinTotalMarks      = getMin(totalMraks);
        
        // Calculating max of each category;
        double MaxAttendanceMarks = getMax(attendancesMarks);
        double MaxAssessmentMarks = getMax(assessmentMraks);
        double MaxMidMarks        = getMax(midTermMarks);
        double MaxFinalMarks      = getMax(finalTermMraks);
        double MaxTotalMarks      = getMax(totalMraks);
        
        // Calculating Averages of each category
        double AvgAttendanceMarks = getAverage(attendancesMarks);
        double AvgAssessmentMarks = getAverage(assessmentMraks);
        double AvgMidMarks        = getAverage(midTermMarks);
        double AvgFinalMarks      = getAverage(finalTermMraks);
        double AvgTotalMarks      = getAverage(totalMraks);

        // Calculating Standard Deviation 
        double STDAttendance = getStandardDeviation(attendancesMarks);
        double STDAssessment = getStandardDeviation(assessmentMraks);
        double STDMid        = getStandardDeviation(midTermMarks);
        double STDFinal      = getStandardDeviation(finalTermMraks);
        double STDTotal      = getStandardDeviation(totalMraks);
        
        // Printing the Statistics
        System.out.println("\n\n\n");
        System.out.printf("Statistical Report:\n");
        System.out.printf("-----------------------------------------------------------------------------------\n");
        System.out.printf("Caterogy     |      Min      |      Max     |     Average   |    Standard Deviation\n");
        System.out.printf("-----------------------------------------------------------------------------------\n");
        System.out.printf("Attendance   : %10.3f    | %10.3f   |  %10.3f   |    %10.3f\n", MinAttendanceMarks, MaxAttendanceMarks, AvgAttendanceMarks, STDAttendance);
        System.out.printf("Assessment   : %10.3f    | %10.3f   |  %10.3f   |    %10.3f\n", MinAssessmentMarks, MaxAssessmentMarks, AvgAssessmentMarks, STDAssessment);
        System.out.printf("Mid          : %10.3f    | %10.3f   |  %10.3f   |    %10.3f\n", MinMidMarks, MaxMidMarks, AvgMidMarks, STDMid);
        System.out.printf("Final        : %10.3f    | %10.3f   |  %10.3f   |    %10.3f\n", MinFinalMarks, MaxFinalMarks, AvgFinalMarks, STDFinal);
        System.out.printf("Total        : %10.3f    | %10.3f   |  %10.3f   |    %10.3f\n", MinTotalMarks, MaxTotalMarks, AvgTotalMarks, STDTotal);
            
            // Printing Histogram of Letter Grades
        System.out.printf("\n\n\n\n");
        System.out.println("|---------------------|");
        System.out.printf("| Histogram of Grades |\n");
        System.out.println("|---------------------|");
        System.out.printf("| Grade    |    Count |\n");
        System.out.println("|---------------------|");
        System.out.printf("| A+       : %5d    |\n", NumberOfAPlus);
        System.out.printf("| A        : %5d    |\n", NumberOfA);
        System.out.printf("| A-       : %5d    |\n", NumberOfAMinus);
        System.out.printf("| B+       : %5d    |\n", NumberOfBPlus);
        System.out.printf("| B        : %5d    |\n", NumberOfB);
        System.out.printf("| B-       : %5d    |\n", NumberOfBMinus);
        System.out.printf("| C+       : %5d    |\n", NumberOfCPlus);
        System.out.printf("| C        : %5d    |\n", NumberOfC);
        System.out.printf("| D        : %5d    |\n", NumberOfD);
        System.out.printf("| F        : %5d    |\n", NumberOfF);
        System.out.println("-----------------------");
        System.out.println();

    }catch(FileNotFoundException fnfe){
            System.err.println("File Not Found.");
    }catch(IOException ioe){
            System.err.println("IO Exception");
        }
        
        
    }
    
    public double getAttendenceMarks(int absentdays){
        
        if(absentdays <= 1) return 5.0;
        
        else {
            absentdays -= 1;
            return (5.0 - (absentdays * 0.5));
        }
        
    }
    
    public double getAssessmentMark(int data[], int parent[]){
        int sum = 0; 
        int total = 0;
        
        double mn = (double)data[0] / parent[0]; 
        double mnTotal = (double)parent[0]; 
        int minimum = data[0];
        
        for (int i = 0; i < data.length; i++) {
            double currentRatio = (double)data[i] / parent[i];
            if (currentRatio < mn){ 
                mn = currentRatio;
                minimum = data[i];
                mnTotal = parent[i];
            }
            sum += data[i];
            total += parent[i];
        }
        sum -= minimum; 
        total -= mnTotal; 
        
        return (sum * 25.0) / total;
        
    }
    
    public String getLetterGrade(double totalMarks){
        
        if(totalMarks >= 80)
            return "A+";
        if(totalMarks >= 75)
            return "A";
        if(totalMarks >= 70)
            return "A-";
        if(totalMarks >= 65)
            return "B+";
        if(totalMarks >= 60)
            return "B";
        if(totalMarks >= 55)
            return "B-";
        if(totalMarks >= 50)
            return "C+";
        if(totalMarks >= 45)
            return "C";
        if(totalMarks >= 40)
            return "D";
        else  return "F";
             
    }
    
    // Function to get minimum of a list
    public double getMin(ArrayList data){
        double mn = Double.MAX_VALUE;
        for (int i=0; i<data.size(); i++)
            mn = Math.min(mn, (double)data.get(i));
        return mn;
    }
    
    // Function to get maximum of a list
    public double getMax(ArrayList data){
        double mx = 0;
        for (int i=0; i<data.size(); i++)
            mx = Math.max(mx, (double)data.get(i));
        return mx;
    }
    
    // Function to get average of a list
    public double getAverage(ArrayList data){
        double sum = 0;
        for (int i=0; i<data.size(); i++)
            sum += (double)data.get(i);
        return sum / data.size();
    }
    
    // Function to get standard deviation of a list
    public double getStandardDeviation(ArrayList data){
        double mean = getAverage(data);
        double sum = 0;
        for (int i=0; i<data.size(); i++)
            sum += (((double)data.get(i) - mean) * ((double)data.get(i) - mean));
        
        mean = sum / data.size();
        return Math.sqrt(mean);
    }
    
    
            

    public static void main(String[] args) {
        new StudentGradeSheet();
        System.out.println("");
    }
    
}
